<?php
/**
 * Do not put custom translations here.
 * They will be deleted upon plugin updates.
 *
 * Keep your custom translations in /wp-content/languages/simple-calendar/
 * They will override plugin translations.
 */
