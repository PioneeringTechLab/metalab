Do not put custom translations here. 
They will be deleted when the plugin updates.

Please help us translating or improving a translation:
https://www.transifex.com/projects/p/simple-calendar/

If you want to add custom translations in your local copy, 
you may place them in /wp-content/languages/simple-calendar/ 

Keep in mind that custom translations will override translations 
for the same languages provided by the plugin.
